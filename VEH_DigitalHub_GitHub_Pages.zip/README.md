# VEH Digital Marketing & Customer Intelligence Hub

Prototype digital marketing untuk Vet Excellence Hub yang mencakup content plan,
content calendar, digital content workflow, audience intelligence, dan evaluasi
performa kanal.

Karya Salma Alya Ristiyana (NIM 255288023), Program S2 Marketing Innovation &
Technology.

## GitHub Pages

Workflow pada `.github/workflows/pages.yml` menerbitkan isi folder `dist` ke
GitHub Pages setiap kali branch `main` diperbarui.
